import Box from '@mui/material/Box'

const Footer = () => {
  return (
    <Box sx={styles.footerBox}>
        
    </Box>
  )
}

export default Footer


const styles = {
    footerBox: {
        mb: (theme) => theme.spacing(8),
    },
}